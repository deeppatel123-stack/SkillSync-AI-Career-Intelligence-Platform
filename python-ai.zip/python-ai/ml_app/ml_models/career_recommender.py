"""
Career Recommendation using Random Forest Classifier.
Recommends the most suitable career path based on student's skills.
"""

import joblib
import numpy as np
import pandas as pd
from pathlib import Path


class CareerRecommender:
    """
    Recommends career paths using a trained Random Forest model.
    """

    def __init__(self):
        """Load the trained model and feature names."""
        models_dir = Path(__file__).resolve().parent.parent / 'trained_models'
        self.model_path = models_dir / 'career_model.pkl'
        self.features_path = models_dir / 'career_features.pkl'

        self.model = None
        self.feature_names = None
        self.load_model()

    def load_model(self):
        """Load the trained model from disk."""
        try:
            self.model = joblib.load(self.model_path)
            self.feature_names = joblib.load(self.features_path)
        except FileNotFoundError:
            print("Warning: Career model not found. Train the model first.")
            print("Run: python -m ml_app.ml_models.train_models")

    def is_model_loaded(self):
        """Check if the model is loaded successfully."""
        return self.model is not None

    def recommend(self, skill_scores):
        """
        Recommend career based on skill scores.
        
        Args:
            skill_scores: dict with skill names and scores (0-1 scale).
                Required keys: html_css, javascript, react, python, database,
                cloud, networking, security, devops, data_science, ai_ml, dsa
        
        Returns:
            dict with recommendations
        """
        if not self.is_model_loaded():
            return {
                'error': 'Model not loaded. Please train the model first.'
            }

        # Prepare input features
        features = []
        for feature in self.feature_names:
            value = skill_scores.get(feature, 0)
            features.append(value)

        features_array = np.array([features])

        # Get prediction
        prediction = self.model.predict(features_array)[0]

        # Get probabilities for all classes
        prediction_proba = self.model.predict_proba(features_array)[0]

        # Get top 3 recommendations
        class_indices = np.argsort(prediction_proba)[::-1][:3]
        class_names = self.model.classes_

        recommendations = []
        for idx in class_indices:
            career_name = class_names[idx]
            probability = float(prediction_proba[idx] * 100)
            recommendations.append({
                'career': career_name,
                'match_percentage': round(probability, 2)
            })

        result = {
            'top_recommendation': prediction,
            'confidence': round(float(max(prediction_proba) * 100), 2),
            'recommendations': recommendations
        }

        return result


# Create a singleton instance
career_recommender = CareerRecommender()
