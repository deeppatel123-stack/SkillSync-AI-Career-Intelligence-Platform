"""
Placement Prediction using Decision Tree Classifier.
Predicts whether a student has high chances of getting placed.
"""

import joblib
import numpy as np
from pathlib import Path


class PlacementPredictor:
    """
    Predicts placement chances using a trained Decision Tree model.
    """

    def __init__(self):
        """Load the trained model and feature names."""
        models_dir = Path(__file__).resolve().parent.parent / 'trained_models'
        self.model_path = models_dir / 'placement_model.pkl'
        self.features_path = models_dir / 'placement_features.pkl'

        self.model = None
        self.feature_names = None
        self.load_model()

    def load_model(self):
        """Load the trained model from disk."""
        try:
            self.model = joblib.load(self.model_path)
            self.feature_names = joblib.load(self.features_path)
        except FileNotFoundError:
            print("Warning: Placement model not found. Train the model first.")
            print("Run: python -m ml_app.ml_models.train_models")

    def is_model_loaded(self):
        """Check if the model is loaded successfully."""
        return self.model is not None

    def predict(self, cgpa, skills_count, internship_count, projects_count,
                certifications_count, aptitude_score, communication_score):
        """
        Predict placement chances for a single student.
        
        Args:
            cgpa: float (0-10 scale)
            skills_count: int
            internship_count: int
            projects_count: int
            certifications_count: int
            aptitude_score: int (0-100)
            communication_score: int (0-100)
        
        Returns:
            dict with prediction results
        """
        if not self.is_model_loaded():
            return {
                'error': 'Model not loaded. Please train the model first.'
            }

        # Prepare input features
        features = np.array([[
            cgpa,
            skills_count,
            internship_count,
            projects_count,
            certifications_count,
            aptitude_score,
            communication_score
        ]])

        # Make prediction
        prediction = self.model.predict(features)[0]
        prediction_proba = self.model.predict_proba(features)[0]

        # Get confidence (probability of the predicted class)
        confidence = float(max(prediction_proba) * 100)

        # Placement probability (probability of being placed, i.e., class 1)
        if len(prediction_proba) == 2:
            placement_probability = float(prediction_proba[1] * 100)
        else:
            placement_probability = float(prediction_proba[0] * 100)

        result = {
            'prediction': int(prediction),
            'placement_probability': round(placement_probability, 2),
            'confidence': round(confidence, 2),
            'is_high_chance': bool(prediction == 1),
            'message': 'Student has high placement chances!' if prediction == 1 else 'Student needs improvement.'
        }

        return result


# Create a singleton instance
placement_predictor = PlacementPredictor()
