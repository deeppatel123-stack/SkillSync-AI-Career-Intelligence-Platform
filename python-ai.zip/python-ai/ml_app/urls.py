"""
URL configuration for the ML app.
Maps API endpoints to their corresponding views.
"""

from django.urls import path
from ml_app import views

urlpatterns = [
    # Health check
    path('health/', views.health_check, name='health-check'),

    # ML Predictions
    path('predict-placement/', views.predict_placement, name='predict-placement'),
    path('recommend-career/', views.recommend_career, name='recommend-career'),
    # Rule-based Features
    path('learning-roadmap/', views.generate_learning_roadmap, name='learning-roadmap'),

    # Data & Analytics
    path('analytics/', views.get_analytics, name='analytics'),
    path('upload-dataset/', views.upload_dataset, name='upload-dataset'),
    path('placement-statistics/', views.get_placement_statistics, name='placement-statistics'),

    # Reference Data
    path('careers/', views.get_available_careers, name='available-careers'),
    path('companies/', views.get_available_companies, name='available-companies'),
]
